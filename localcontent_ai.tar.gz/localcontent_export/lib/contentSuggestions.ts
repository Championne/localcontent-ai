// Content Suggestions Database
// Industry-specific prefilled content for events and goals

export interface ContentSuggestion {
  topic: string
  template: 'social-pack' | 'gmb-post' | 'blog-post' | 'email'
  gbpPostType?: 'offer' | 'event' | 'update'
  tone: 'professional' | 'friendly' | 'casual' | 'urgent'
  suggestions: {
    primary: string
    alternatives?: string[]
  }
}

// Industry-specific suggestions for events/holidays
export const EVENT_SUGGESTIONS: Record<string, Record<string, ContentSuggestion>> = {
  // National Pizza Day
  'national-pizza-day': {
    restaurant: {
      topic: 'National Pizza Day celebration',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "It's National Pizza Day! 🍕 Celebrate with us today - every pizza made fresh with love, just the way you like it. Tag someone who deserves a slice!",
        alternatives: [
          "Behind the scenes: Watch our dough masters work their magic this National Pizza Day! Fresh ingredients, traditional recipes, unforgettable taste.",
          "National Pizza Day special: Buy any large, get a medium FREE! Today only. Because pizza is meant to be shared. 🍕"
        ]
      }
    },
    default: {
      topic: 'National Pizza Day',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy National Pizza Day! 🍕 What's your go-to order? Whether you're team pepperoni or pineapple (we don't judge!), today's the day to treat yourself!",
        alternatives: [
          "It's National Pizza Day! Supporting local pizza shops today? Tag your favorite spot below! 🍕"
        ]
      }
    }
  },

  // Valentine's Day
  'valentines-day': {
    restaurant: {
      topic: "Valentine's Day special",
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Make this Valentine's Day unforgettable 💕 Treat your special someone to a romantic dinner at our place. Book your table now - spots are filling fast!",
        alternatives: [
          "Love is in the air... and so is the aroma of our Valentine's Day menu! 🌹 Special 3-course dinner for two. Reserve today."
        ]
      }
    },
    salon: {
      topic: "Valentine's Day special",
      template: 'gmb-post',
      gbpPostType: 'offer',
      tone: 'friendly',
      suggestions: {
        primary: "Look amazing this Valentine's Day! 💕 Book your hair & makeup appointment now. Special couples packages available - treat yourself or gift someone special!",
        alternatives: [
          "Valentine's ready? We've got you! Special offer: Blowout + makeup for $75. Limited slots available for Feb 14th!"
        ]
      }
    },
    default: {
      topic: "Valentine's Day",
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy Valentine's Day from our team! 💕 Whether you're celebrating with someone special or treating yourself, we hope your day is filled with love!",
        alternatives: [
          "Love your community this Valentine's Day! Share some love in the comments - what do you appreciate most about our local neighborhood? 💕"
        ]
      }
    }
  },

  // St. Patrick's Day
  'st-patricks-day': {
    restaurant: {
      topic: "St. Patrick's Day celebration",
      template: 'gmb-post',
      gbpPostType: 'event',
      tone: 'friendly',
      suggestions: {
        primary: "Get lucky this St. Patrick's Day! 🍀 Join us for live music, green specials, and good times. No blarney - just great food and fun!",
        alternatives: [
          "Feeling lucky? 🍀 St. Patrick's Day special: Wear green and get 15% off your meal! Sláinte!"
        ]
      }
    },
    default: {
      topic: "St. Patrick's Day",
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy St. Patrick's Day! 🍀 May your day be touched by a bit of Irish luck. What's your favorite way to celebrate?",
        alternatives: [
          "Feeling lucky? 🍀 Happy St. Patrick's Day from our team to yours!"
        ]
      }
    }
  },

  // Easter
  'easter': {
    restaurant: {
      topic: 'Easter celebration',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy Easter from our family to yours! 🐣 We're serving up springtime specials all weekend. Come celebrate with us!",
        alternatives: [
          "Easter brunch is calling! 🐰 Treat the family to a delicious meal this Sunday. Reservations recommended!"
        ]
      }
    },
    default: {
      topic: 'Easter',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy Easter! 🐣 Wishing you a joyful spring celebration with friends and family. What are your Easter traditions?",
        alternatives: [
          "Spring has sprung! 🌷 Happy Easter from our team. We hope your day is filled with joy!"
        ]
      }
    }
  },

  // Mother's Day
  'mothers-day': {
    restaurant: {
      topic: "Mother's Day special",
      template: 'gmb-post',
      gbpPostType: 'event',
      tone: 'friendly',
      suggestions: {
        primary: "Treat Mom to the meal she deserves! 💐 Mother's Day reservations now open. Make this day special with our exclusive brunch menu.",
        alternatives: [
          "Don't forget Mom! 💕 Book her favorite table for Mother's Day. Early reservations get a complimentary dessert!"
        ]
      }
    },
    salon: {
      topic: "Mother's Day special",
      template: 'gmb-post',
      gbpPostType: 'offer',
      tone: 'friendly',
      suggestions: {
        primary: "Give Mom the gift of relaxation! 💐 Mother's Day spa packages available now. Book early - slots fill up fast!",
        alternatives: [
          "She deserves it! Treat Mom (or yourself!) to our Mother's Day special - full service at 20% off!"
        ]
      }
    },
    default: {
      topic: "Mother's Day",
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy Mother's Day to all the amazing moms out there! 💐 You deserve the world. How are you celebrating?",
        alternatives: [
          "To all the moms, grandmoms, stepmoms, and mother figures - thank you! 💕 Happy Mother's Day!"
        ]
      }
    }
  },

  // Father's Day
  'fathers-day': {
    restaurant: {
      topic: "Father's Day special",
      template: 'gmb-post',
      gbpPostType: 'event',
      tone: 'friendly',
      suggestions: {
        primary: "Dad's day, Dad's way! 👔 Bring him in for his favorite meal this Father's Day. Free appetizer for all dads!",
        alternatives: [
          "Celebrate the man who taught you everything! Father's Day reservations now open. Make it memorable!"
        ]
      }
    },
    default: {
      topic: "Father's Day",
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy Father's Day! 👔 Here's to the dads, stepdads, grandpas, and father figures who make a difference. How are you celebrating?",
        alternatives: [
          "To all the hardworking dads out there - today is YOUR day! Happy Father's Day! 🎉"
        ]
      }
    }
  },

  // Independence Day
  'independence-day': {
    restaurant: {
      topic: 'July 4th celebration',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy 4th of July! 🇺🇸 Celebrate freedom with great food. We're open and serving up your favorites. See you soon!",
        alternatives: [
          "Red, white, and BBQ! 🎆 Come celebrate Independence Day with us. Special patriotic menu all weekend!"
        ]
      }
    },
    default: {
      topic: 'July 4th',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy 4th of July! 🇺🇸 Wishing everyone a safe and happy Independence Day celebration. What are your plans?",
        alternatives: [
          "Land of the free, home of the brave! 🎆 Happy Independence Day from our team!"
        ]
      }
    }
  },

  // Halloween
  'halloween': {
    restaurant: {
      topic: 'Halloween celebration',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Trick or treat yourself! 🎃 Stop by for our spooky Halloween specials. Costume contest tonight - best costume wins a free meal!",
        alternatives: [
          "Something wicked this way comes... our Halloween menu! 👻 Join us for frightfully good food this weekend."
        ]
      }
    },
    default: {
      topic: 'Halloween',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy Halloween! 🎃 What's everyone dressing up as this year? Share your costume ideas below!",
        alternatives: [
          "Boo! 👻 Happy Halloween from our team. Stay spooky and safe out there!"
        ]
      }
    }
  },

  // Thanksgiving
  'thanksgiving': {
    restaurant: {
      topic: 'Thanksgiving special',
      template: 'gmb-post',
      gbpPostType: 'event',
      tone: 'friendly',
      suggestions: {
        primary: "Let us do the cooking this Thanksgiving! 🦃 Pre-order your feast or join us for our special holiday menu. Family, food, and gratitude.",
        alternatives: [
          "Skip the dishes! Thanksgiving catering now available. Spend the day with family, not in the kitchen. Order now!"
        ]
      }
    },
    default: {
      topic: 'Thanksgiving',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy Thanksgiving! 🦃 We're grateful for every single one of you. What are you most thankful for this year?",
        alternatives: [
          "Grateful for our amazing community! 🙏 Happy Thanksgiving from our family to yours."
        ]
      }
    }
  },

  // Christmas
  'christmas': {
    restaurant: {
      topic: 'Holiday special',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Merry Christmas! 🎄 Wishing you a season filled with joy, delicious food, and time with loved ones. Thank you for an amazing year!",
        alternatives: [
          "Holiday catering made easy! 🎁 Let us help with your Christmas gathering. Pre-orders now open!"
        ]
      }
    },
    default: {
      topic: 'Christmas/Holiday season',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Merry Christmas & Happy Holidays! 🎄 Thank you for being part of our journey this year. Wishing you joy and peace!",
        alternatives: [
          "'Tis the season! 🎁 Happy Holidays from everyone at our team. See you in the new year!"
        ]
      }
    }
  },

  // New Year's Eve
  'new-years-eve': {
    restaurant: {
      topic: "New Year's celebration",
      template: 'gmb-post',
      gbpPostType: 'event',
      tone: 'friendly',
      suggestions: {
        primary: "Ring in 2027 with us! 🎆 New Year's Eve special menu + champagne toast at midnight. Limited seats - book now!",
        alternatives: [
          "New Year, new memories! Join us for our NYE celebration. Music, food, and the countdown together!"
        ]
      }
    },
    default: {
      topic: "New Year's Eve",
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "Happy New Year! 🎆 Thank you for an incredible year. We can't wait to serve you even better in 2027. What's your resolution?",
        alternatives: [
          "Out with the old, in with the new! 🥳 Cheers to new beginnings. Happy New Year!"
        ]
      }
    }
  }
}

// Goal-based suggestions (What do you want to achieve?)
export const GOAL_SUGGESTIONS: Record<string, Record<string, ContentSuggestion>> = {
  // Promote an Offer
  'promote-offer': {
    restaurant: {
      topic: 'Special limited-time offer',
      template: 'gmb-post',
      gbpPostType: 'offer',
      tone: 'urgent',
      suggestions: {
        primary: "This week only! 🎉 Get 20% off your entire order. Dine-in or takeout - you choose. Use code SAVE20 or just mention this post. Don't miss out!",
        alternatives: [
          "Family deal alert! 👨‍👩‍👧‍👦 Feed the whole crew for just $39.99. Includes appetizer, 2 mains, 2 kids meals & dessert. Limited time!"
        ]
      }
    },
    salon: {
      topic: 'Special offer',
      template: 'gmb-post',
      gbpPostType: 'offer',
      tone: 'friendly',
      suggestions: {
        primary: "New client special! ✨ First visit? Get 50% off any service. We can't wait to meet you and show you why our clients keep coming back!",
        alternatives: [
          "Refer a friend, get rewarded! 💕 You both get $20 off your next appointment. Because good hair days are better shared!"
        ]
      }
    },
    fitness: {
      topic: 'Membership offer',
      template: 'gmb-post',
      gbpPostType: 'offer',
      tone: 'urgent',
      suggestions: {
        primary: "New Year, New You! 💪 Join this month and get your first month FREE. No contracts, no gimmicks - just results. Start your fitness journey today!",
        alternatives: [
          "Bring a buddy special! 🏋️ Sign up together and you both save 30% on your first 3 months. Accountability partners welcome!"
        ]
      }
    },
    default: {
      topic: 'Special offer',
      template: 'gmb-post',
      gbpPostType: 'offer',
      tone: 'urgent',
      suggestions: {
        primary: "Limited time offer! 🎉 We're offering something special for our valued customers this week. Come see us and mention this post for your exclusive deal!",
        alternatives: [
          "Thank you for your support! As a token of appreciation, enjoy a special discount this week. Stop by or call us for details!"
        ]
      }
    }
  },

  // Get More Reviews
  'get-reviews': {
    restaurant: {
      topic: 'Request for reviews',
      template: 'email',
      tone: 'friendly',
      suggestions: {
        primary: "Hi there! 👋\n\nThank you for dining with us recently! We hope you enjoyed your meal.\n\nIf you have a moment, we'd love to hear about your experience. A quick Google review helps other food lovers find us and means the world to our team.\n\nThank you for being part of our community!\n\nWarm regards,\nYour friends at [Business Name]",
        alternatives: [
          "Loved your meal? 🍽️ Share the love! A quick Google review helps us keep doing what we love - serving amazing food to amazing people like you."
        ]
      }
    },
    default: {
      topic: 'Request for reviews',
      template: 'email',
      tone: 'friendly',
      suggestions: {
        primary: "Hi there! 👋\n\nThank you for choosing us! We hope we exceeded your expectations.\n\nYour feedback means everything to us. If you have a moment, a quick Google review would help other customers find us.\n\nThank you for your support!\n\nBest,\n[Business Name]",
        alternatives: [
          "Happy with your experience? We'd be grateful if you could share a quick review. It helps our small business grow and lets others know what to expect!"
        ]
      }
    }
  },

  // Share News
  'share-news': {
    restaurant: {
      topic: 'Business announcement',
      template: 'blog-post',
      tone: 'professional',
      suggestions: {
        primary: "Exciting news! We're thrilled to announce some changes that we think you're going to love. After listening to your feedback, we've been working hard behind the scenes...\n\n[Share your news: new menu items, extended hours, renovations, new location, etc.]\n\nThank you for being part of our journey. We can't wait to share this with you!",
        alternatives: [
          "Big things are happening! 🎉 We've got news to share and we couldn't be more excited. Stay tuned for the full reveal!"
        ]
      }
    },
    default: {
      topic: 'Business announcement',
      template: 'blog-post',
      tone: 'professional',
      suggestions: {
        primary: "We have some exciting news to share! 🎉\n\nOur team has been working on something special, and we're finally ready to tell you about it.\n\n[Share your news: new services, achievements, milestones, changes, etc.]\n\nThank you for your continued support. This wouldn't be possible without you!",
        alternatives: [
          "Announcement time! We've got something exciting in the works. Here's what's new and what it means for you..."
        ]
      }
    }
  },

  // Showcase Work
  'showcase-work': {
    salon: {
      topic: 'Recent work showcase',
      template: 'social-pack',
      tone: 'professional',
      suggestions: {
        primary: "Transformation Tuesday! ✨ Swipe to see this amazing before & after. Our client wanted a fresh look for spring, and we delivered! Book your transformation today.",
        alternatives: [
          "Another happy client! 💇‍♀️ We love helping people feel confident and beautiful. Ready for your glow-up? Link in bio to book!"
        ]
      }
    },
    contractor: {
      topic: 'Project showcase',
      template: 'social-pack',
      tone: 'professional',
      suggestions: {
        primary: "Project complete! 🏠 We just finished this kitchen renovation and we couldn't be prouder. Swipe to see the transformation. Ready for your project? Let's talk!",
        alternatives: [
          "From vision to reality! 🔨 Another satisfied homeowner. We love turning dreams into beautiful spaces. What's your next project?"
        ]
      }
    },
    default: {
      topic: 'Work showcase',
      template: 'social-pack',
      tone: 'professional',
      suggestions: {
        primary: "Check out our recent work! ✨ We put our heart into every project, and this one was no exception. Swipe to see the results!",
        alternatives: [
          "Proud of this one! Another project completed with care and attention to detail. This is why we love what we do!"
        ]
      }
    }
  },

  // Build Community  
  'build-community': {
    restaurant: {
      topic: 'Community engagement',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "We love our community! 💕 This isn't just a restaurant - it's where neighbors become friends over great food. Who's your favorite person to share a meal with? Tag them!",
        alternatives: [
          "Behind every dish is our amazing team! 👨‍🍳 Meet our head chef who's been with us for 5 years. They're the reason your favorites taste so good!"
        ]
      }
    },
    default: {
      topic: 'Community connection',
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: "We're proud to be part of this amazing community! 💕 Thank you for supporting local. What do you love most about our neighborhood?",
        alternatives: [
          "Small business, big heart! ❤️ We're here because of you. Share your favorite memory with us in the comments!"
        ]
      }
    }
  },

  // Share Tips (for blog posts)
  'share-tips': {
    restaurant: {
      topic: 'Expert tips and advice',
      template: 'blog-post',
      tone: 'professional',
      suggestions: {
        primary: "Cooking Tips from Our Kitchen\n\nWant to bring restaurant-quality flavor to your home cooking? Here are some pro tips from our chef:\n\n1. Season as you go, not just at the end\n2. Let your meat rest before cutting\n3. Don't crowd the pan when searing\n4. Taste, taste, taste!\n\nWhat's your favorite cooking tip?",
        alternatives: [
          "The secret ingredient? It's not what you think! Here are 5 simple tips that will elevate your home cooking to the next level..."
        ]
      }
    },
    salon: {
      topic: 'Hair care tips',
      template: 'blog-post',
      tone: 'friendly',
      suggestions: {
        primary: "Hair Care Secrets from the Pros\n\nWant salon-perfect hair at home? Here are our top tips:\n\n1. Use lukewarm water (hot water damages!)\n2. Don't skip conditioner\n3. Protect before heat styling\n4. Get regular trims\n\nWhat's your biggest hair struggle? Drop it in the comments!",
        alternatives: [
          "Dry, damaged hair? We see it all the time. Here's what's probably causing it and how to fix it..."
        ]
      }
    },
    default: {
      topic: 'Tips and advice',
      template: 'blog-post',
      tone: 'professional',
      suggestions: {
        primary: "Expert Tips from [Your Industry]\n\nWe get asked these questions all the time, so here are our top tips:\n\n1. [First tip]\n2. [Second tip]\n3. [Third tip]\n\nThese simple changes can make a big difference. Have questions? We're always happy to help!",
        alternatives: [
          "The top 5 mistakes we see (and how to avoid them). Quick tips that will save you time and money..."
        ]
      }
    }
  }
}

// Suggestions for industry trends (used on the "Perfect for you right now" section)
export const TREND_SUGGESTIONS: Record<string, ContentSuggestion> = {
  // Behind the scenes
  'behind-the-scenes-kitchen-tour': {
    topic: 'Behind the scenes in our kitchen',
    template: 'social-pack',
    tone: 'friendly',
    suggestions: {
      primary: "Ever wonder what happens behind those kitchen doors? 👀 Here's a sneak peek at where the magic happens! Fresh ingredients, passionate chefs, and a whole lot of love.",
      alternatives: [
        "Kitchen tour time! 🍳 Come see where your favorite dishes are made. Spoiler: lots of love goes into every plate!"
      ]
    }
  },
  'meet-the-chef': {
    topic: 'Meet our head chef',
    template: 'social-pack',
    tone: 'friendly',
    suggestions: {
      primary: "Meet the mastermind behind your favorite dishes! 👨‍🍳 [Name] has been creating culinary magic for [X] years. Their secret? Passion, fresh ingredients, and a little bit of love in every dish.",
      alternatives: [
        "The face behind the flavors! Get to know our amazing chef who makes every meal special."
      ]
    }
  },
  'customer-favorites-post': {
    topic: 'Our most popular dishes',
    template: 'social-pack',
    tone: 'friendly',
    suggestions: {
      primary: "You spoke, we listened! 🏆 Here are YOUR top 3 favorites this month:\n\n1. [Dish 1]\n2. [Dish 2]\n3. [Dish 3]\n\nHave you tried them all? Which one's your go-to?",
      alternatives: [
        "What's everyone ordering? Here are the crowd favorites that keep people coming back!"
      ]
    }
  },
  'new-menu-item-tease': {
    topic: 'New menu item preview',
    template: 'social-pack',
    tone: 'friendly',
    suggestions: {
      primary: "Something delicious is coming... 🤫 We've been working on a new addition to the menu and we can't wait to share it with you! Any guesses? Hint: it involves [ingredient]...",
      alternatives: [
        "Sneak peek alert! 👀 A new favorite is hitting the menu soon. Stay tuned!"
      ]
    }
  },
  'tips---tricks': {
    topic: 'Helpful tips from our experts',
    template: 'social-pack',
    tone: 'professional',
    suggestions: {
      primary: "Pro tip! 💡 Here's something we've learned over the years that can help you: [Share a relevant tip for your industry]. Save this for later!",
      alternatives: [
        "Did you know? Quick tip that might save you time/money/hassle..."
      ]
    }
  },
  'special-announcement': {
    topic: 'Exciting news',
    template: 'social-pack',
    tone: 'friendly',
    suggestions: {
      primary: "We've got news! 🎉 [Share your announcement]. Thank you for being part of our journey - we couldn't do this without you!",
      alternatives: [
        "Big news coming your way! We're excited to announce..."
      ]
    }
  }
}

// Helper function to get suggestion based on event/goal and industry
export function getSuggestion(
  type: 'event' | 'goal',
  key: string,
  industry: string
): ContentSuggestion {
  // First check for trend suggestions
  if (TREND_SUGGESTIONS[key]) {
    return TREND_SUGGESTIONS[key]
  }

  const database = type === 'event' ? EVENT_SUGGESTIONS : GOAL_SUGGESTIONS
  const eventOrGoal = database[key]
  
  if (!eventOrGoal) {
    // Return generic default
    return {
      topic: key.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
      template: 'social-pack',
      tone: 'friendly',
      suggestions: {
        primary: `Share something great about ${key.replace(/-/g, ' ')}! What makes this special for your business and community?`
      }
    }
  }

  // Try to find industry-specific suggestion
  const industryLower = industry.toLowerCase()
  
  // Map common industries to our categories
  const industryMap: Record<string, string> = {
    'pizza': 'restaurant',
    'pizzeria': 'restaurant',
    'italian': 'restaurant',
    'cafe': 'restaurant',
    'coffee': 'restaurant',
    'bakery': 'restaurant',
    'bar': 'restaurant',
    'pub': 'restaurant',
    'food': 'restaurant',
    'dining': 'restaurant',
    'restaurant': 'restaurant',
    'hair': 'salon',
    'beauty': 'salon',
    'spa': 'salon',
    'nail': 'salon',
    'barber': 'salon',
    'salon': 'salon',
    'gym': 'fitness',
    'fitness': 'fitness',
    'yoga': 'fitness',
    'personal trainer': 'fitness',
    'construction': 'contractor',
    'contractor': 'contractor',
    'plumber': 'contractor',
    'electrician': 'contractor',
    'handyman': 'contractor',
    'renovation': 'contractor',
  }

  // Find matching category
  let category = 'default'
  for (const [keyword, cat] of Object.entries(industryMap)) {
    if (industryLower.includes(keyword)) {
      category = cat
      break
    }
  }

  return eventOrGoal[category] || eventOrGoal['default']
}
