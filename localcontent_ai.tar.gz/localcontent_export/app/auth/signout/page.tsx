'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

export default function SignOutPage() {
  const [status, setStatus] = useState('Signing out...')
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const handleSignOut = async () => {
      try {
        await supabase.auth.signOut()
        setStatus('Signed out successfully. Redirecting...')
        setTimeout(() => {
          router.push('/')
        }, 500)
      } catch (error) {
        setStatus('Error signing out. Redirecting...')
        setTimeout(() => {
          router.push('/')
        }, 1000)
      }
    }

    handleSignOut()
  }, [supabase.auth, router])

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
        <p className="text-muted-foreground">{status}</p>
      </div>
    </div>
  )
}