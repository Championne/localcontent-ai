import Link from 'next/link'

export const metadata = {
  title: 'Privacy Policy | GeoSpark',
  description: 'Privacy Policy for GeoSpark - How we collect, use, and protect your data',
}

export default function PrivacyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-16">
      <h1 className="text-4xl font-bold mb-8">Privacy Policy</h1>
      <p className="text-gray-500 mb-8">Last updated: January 31, 2026</p>

      <div className="prose prose-gray max-w-none">
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">1. Introduction</h2>
          <p className="text-gray-600 mb-4">
            GeoSpark ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy 
            explains how we collect, use, disclose, and safeguard your information when you use our 
            AI-powered content generation platform.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">2. Information We Collect</h2>
          
          <h3 className="text-xl font-medium mb-3 mt-6">Personal Information</h3>
          <p className="text-gray-600 mb-4">When you create an account, we collect:</p>
          <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
            <li>Name and email address</li>
            <li>Business name and industry</li>
            <li>Business location (optional)</li>
            <li>Profile photos and logos you upload</li>
            <li>Payment information (processed securely by our payment provider)</li>
          </ul>

          <h3 className="text-xl font-medium mb-3 mt-6">Usage Information</h3>
          <p className="text-gray-600 mb-4">We automatically collect:</p>
          <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
            <li>Content you generate using the Service</li>
            <li>Topics and inputs you provide for content generation</li>
            <li>Service usage patterns and preferences</li>
            <li>Device information and IP address</li>
            <li>Browser type and operating system</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">3. How We Use Your Information</h2>
          <p className="text-gray-600 mb-4">We use your information to:</p>
          <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
            <li>Provide and improve our content generation services</li>
            <li>Process your subscription and payments</li>
            <li>Send you service updates and marketing communications (with your consent)</li>
            <li>Respond to your inquiries and support requests</li>
            <li>Analyze usage patterns to improve the Service</li>
            <li>Prevent fraud and ensure security</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">4. AI Processing</h2>
          <p className="text-gray-600 mb-4">
            When you use our content generation features, your inputs (such as business name, industry, 
            and topic) are processed by AI systems to generate content. We use third-party AI services 
            (such as OpenAI) to power our content generation.
          </p>
          <p className="text-gray-600 mb-4">
            Your inputs may be processed by these AI providers according to their privacy policies. 
            We do not use your content to train AI models.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">5. Data Sharing</h2>
          <p className="text-gray-600 mb-4">We may share your information with:</p>
          <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
            <li><strong>Service Providers:</strong> Third parties that help us operate the Service (payment processors, hosting providers, AI services)</li>
            <li><strong>Legal Requirements:</strong> When required by law or to protect our rights</li>
            <li><strong>Business Transfers:</strong> In connection with a merger, acquisition, or sale of assets</li>
          </ul>
          <p className="text-gray-600 mb-4">
            We do not sell your personal information to third parties.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">6. Data Security</h2>
          <p className="text-gray-600 mb-4">
            We implement appropriate technical and organizational measures to protect your information, 
            including encryption, secure servers, and access controls. However, no method of transmission 
            over the internet is 100% secure.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">7. Data Retention</h2>
          <p className="text-gray-600 mb-4">
            We retain your information for as long as your account is active or as needed to provide 
            services. You can request deletion of your account and associated data at any time.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">8. Your Rights</h2>
          <p className="text-gray-600 mb-4">Depending on your location, you may have the right to:</p>
          <ul className="list-disc pl-6 text-gray-600 mb-4 space-y-2">
            <li>Access the personal information we hold about you</li>
            <li>Correct inaccurate information</li>
            <li>Delete your personal information</li>
            <li>Object to or restrict processing of your information</li>
            <li>Data portability</li>
            <li>Withdraw consent at any time</li>
          </ul>
          <p className="text-gray-600 mb-4">
            To exercise these rights, please contact us through our contact page.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">9. Cookies</h2>
          <p className="text-gray-600 mb-4">
            We use cookies and similar technologies to maintain your session, remember your preferences, 
            and analyze usage. You can control cookies through your browser settings.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">10. Children&apos;s Privacy</h2>
          <p className="text-gray-600 mb-4">
            The Service is not intended for users under 16 years of age. We do not knowingly collect 
            information from children under 16.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">11. International Transfers</h2>
          <p className="text-gray-600 mb-4">
            Your information may be transferred to and processed in countries other than your own. 
            We ensure appropriate safeguards are in place for such transfers.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">12. Changes to This Policy</h2>
          <p className="text-gray-600 mb-4">
            We may update this Privacy Policy from time to time. We will notify you of significant 
            changes via email or through the Service.
          </p>
        </section>

        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">13. Contact Us</h2>
          <p className="text-gray-600 mb-4">
            If you have questions about this Privacy Policy or our data practices, please contact us at{' '}
            <Link href="/contact" className="text-teal-600 hover:underline">our contact page</Link>.
          </p>
        </section>
      </div>

      <div className="mt-12 pt-8 border-t">
        <Link href="/" className="text-teal-600 hover:underline">
          &larr; Back to Home
        </Link>
      </div>
    </div>
  )
}