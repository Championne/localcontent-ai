import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

// GET /api/content - Get user's content library
export async function GET(request: Request) {
  const supabase = createClient()
  
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  
  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { searchParams } = new URL(request.url)
    const template = searchParams.get('template')
    const status = searchParams.get('status')
    const limit = parseInt(searchParams.get('limit') || '50')
    const offset = parseInt(searchParams.get('offset') || '0')

    // Build query
    let query = supabase
      .from('content')
      .select('*', { count: 'exact' })
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1)

    // Apply filters
    if (template) {
      query = query.eq('template', template)
    }
    if (status) {
      query = query.eq('status', status)
    }

    const { data: content, error, count } = await query

    if (error) {
      console.error('Content fetch error:', error)
      return NextResponse.json({ error: 'Failed to fetch content' }, { status: 500 })
    }

    return NextResponse.json({
      content: content || [],
      total: count || 0,
      limit,
      offset
    })

  } catch (error) {
    console.error('Content API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// POST /api/content - Save new content
export async function POST(request: Request) {
  const supabase = createClient()
  
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  
  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const body = await request.json()
    const { 
      template, 
      title, 
      content, 
      metadata = {},
      status = 'draft',
      business_id = null,
      image_url = null,
      image_style = null
    } = body

    if (!template || !content) {
      return NextResponse.json(
        { error: 'Missing required fields: template, content' },
        { status: 400 }
      )
    }

    // Store image info in metadata since columns may not exist
    const enrichedMetadata = {
      ...metadata,
      image_url: image_url || undefined,
      image_style: image_style || undefined
    }

    const { data, error } = await supabase
      .from('content')
      .insert({
        user_id: user.id,
        business_id,
        template,
        title: title || metadata.topic || 'Untitled',
        content,
        metadata: enrichedMetadata,
        status
      })
      .select()
      .single()

    if (error) {
      console.error('Content save error:', error)
      return NextResponse.json({ error: 'Failed to save content: ' + error.message }, { status: 500 })
    }

    return NextResponse.json({ 
      success: true,
      content: data 
    }, { status: 201 })

  } catch (error) {
    console.error('Content POST error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// PATCH /api/content - Update content
export async function PATCH(request: Request) {
  const supabase = createClient()
  
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  
  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const body = await request.json()
    const { id, ...updates } = body

    if (!id) {
      return NextResponse.json({ error: 'Missing content id' }, { status: 400 })
    }

    // Only allow updating certain fields
    const allowedFields = ['title', 'content', 'status', 'metadata', 'scheduled_for']
    const sanitizedUpdates: Record<string, any> = {}
    for (const field of allowedFields) {
      if (updates[field] !== undefined) {
        sanitizedUpdates[field] = updates[field]
      }
    }
    sanitizedUpdates.updated_at = new Date().toISOString()

    const { data, error } = await supabase
      .from('content')
      .update(sanitizedUpdates)
      .eq('id', id)
      .eq('user_id', user.id)
      .select()
      .single()

    if (error) {
      console.error('Content update error:', error)
      return NextResponse.json({ error: 'Failed to update content' }, { status: 500 })
    }

    return NextResponse.json({ 
      success: true,
      content: data 
    })

  } catch (error) {
    console.error('Content PATCH error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}