import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe/stripe'
import { headers } from 'next/headers'

// Map plan names from pricing page to Stripe price IDs
const PLAN_TO_PRICE_ID: Record<string, { monthly?: string; annual?: string }> = {
  starter: {
    monthly: process.env.STRIPE_STARTER_MONTHLY_PRICE_ID,
    annual: process.env.STRIPE_STARTER_ANNUAL_PRICE_ID,
  },
  pro: {
    monthly: process.env.STRIPE_PRO_MONTHLY_PRICE_ID,
    annual: process.env.STRIPE_PRO_ANNUAL_PRICE_ID,
  },
  premium: {
    monthly: process.env.STRIPE_PREMIUM_MONTHLY_PRICE_ID,
    annual: process.env.STRIPE_PREMIUM_ANNUAL_PRICE_ID,
  },
}

export async function POST(request: Request) {
  const supabase = createClient()
  
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  
  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const body = await request.json()
    const { plan, billing = 'monthly' } = body

    if (!plan || !PLAN_TO_PRICE_ID[plan]) {
      return NextResponse.json({ error: 'Invalid plan. Choose: starter, pro, or premium' }, { status: 400 })
    }

    const priceId = PLAN_TO_PRICE_ID[plan][billing as 'monthly' | 'annual']
    
    if (!priceId) {
      return NextResponse.json({ 
        error: 'Price not configured for ' + plan + ' (' + billing + '). Please set STRIPE_' + plan.toUpperCase() + '_' + billing.toUpperCase() + '_PRICE_ID in environment variables.'
      }, { status: 400 })
    }

    // Get origin from headers
    const headersList = await headers()
    const host = headersList.get('host') || 'localhost:3000'
    const protocol = headersList.get('x-forwarded-proto') || (host.includes('localhost') ? 'http' : 'https')
    const origin = protocol + '://' + host

    // Check if user already has a subscription
    const { data: subscription } = await supabase
      .from('subscriptions')
      .select('stripe_customer_id, stripe_subscription_id, plan, status')
      .eq('user_id', user.id)
      .single()

    let customerId = subscription?.stripe_customer_id

    // Create Stripe customer if not exists
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email!,
        metadata: {
          supabase_user_id: user.id,
        },
      })
      customerId = customer.id

      // Save customer ID to subscription record (create if doesn't exist)
      if (subscription) {
        await supabase
          .from('subscriptions')
          .update({ stripe_customer_id: customerId })
          .eq('user_id', user.id)
      } else {
        await supabase
          .from('subscriptions')
          .insert({
            user_id: user.id,
            stripe_customer_id: customerId,
            plan: 'free',
            status: 'active',
            content_limit: 5,
            content_used: 0,
          })
      }
    }

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      subscription_data: {
        trial_period_days: 14,
        metadata: {
          supabase_user_id: user.id,
          plan: plan,
        },
      },
      success_url: origin + '/dashboard?checkout=success',
      cancel_url: origin + '/pricing?checkout=cancelled',
      metadata: {
        supabase_user_id: user.id,
        plan: plan,
      },
    })

    return NextResponse.json({ url: session.url })
  } catch (error: any) {
    console.error('Checkout error:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to create checkout session' },
      { status: 500 }
    )
  }
}
