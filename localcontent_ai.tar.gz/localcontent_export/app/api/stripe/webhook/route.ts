import { createClient } from '@/lib/supabase/server'
import { stripe } from '@/lib/stripe/stripe'
import { NextResponse } from 'next/server'
import { headers } from 'next/headers'
import Stripe from 'stripe'

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!

export async function POST(request: Request) {
  const body = await request.text()
  const headersList = await headers()
  const signature = headersList.get('stripe-signature')

  if (!signature) {
    return NextResponse.json({ error: 'No signature' }, { status: 400 })
  }

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
  } catch (err: any) {
    console.error('Webhook signature verification failed:', err.message)
    return NextResponse.json({ error: 'Webhook Error: ' + err.message }, { status: 400 })
  }

  const supabase = createClient()

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session
        const userId = session.metadata?.supabase_user_id
        const plan = session.metadata?.plan || 'starter'

        if (!userId) {
          console.error('No user ID in checkout session metadata')
          break
        }

        const subscriptionId = session.subscription as string
        if (subscriptionId) {
          const subscription = await stripe.subscriptions.retrieve(subscriptionId)
          
          await supabase
            .from('subscriptions')
            .update({
              stripe_subscription_id: subscriptionId,
              plan: plan as 'starter' | 'pro' | 'premium',
              status: subscription.status === 'active' || subscription.status === 'trialing' ? 'active' : 'canceled',
              current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
              current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
              content_limit: plan === 'starter' ? 30 : plan === 'pro' ? 100 : 999999,
            })
            .eq('user_id', userId)
        }
        break
      }

      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription
        const userId = subscription.metadata?.supabase_user_id

        if (!userId) {
          const { data: sub } = await supabase
            .from('subscriptions')
            .select('user_id')
            .eq('stripe_customer_id', subscription.customer as string)
            .single()

          if (!sub) {
            console.error('Could not find user for subscription update')
            break
          }
        }

        const status = subscription.status === 'active' || subscription.status === 'trialing' 
          ? 'active' 
          : subscription.status === 'past_due' 
          ? 'past_due' 
          : 'canceled'

        await supabase
          .from('subscriptions')
          .update({
            status: status,
            current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
            current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
          })
          .eq('stripe_subscription_id', subscription.id)

        break
      }

      default:
        console.log('Unhandled event type: ' + event.type)
    }

    return NextResponse.json({ received: true })
  } catch (error: any) {
    console.error('Webhook handler error:', error)
    return NextResponse.json(
      { error: 'Webhook handler failed: ' + error.message },
      { status: 500 }
    )
  }
}