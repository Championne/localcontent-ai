'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'

interface ContentItem {
  id: string
  title: string
  template: string
  content: string
  status: 'draft' | 'published' | 'scheduled'
  created_at: string
  updated_at: string
}

export default function ContentLibraryPage() {
  const [content, setContent] = useState<ContentItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [filter, setFilter] = useState({ type: '', status: '', search: '' })

  useEffect(() => {
    fetchContent()
  }, [])

  const fetchContent = async () => {
    try {
      const params = new URLSearchParams()
      if (filter.type) params.set('template', filter.type)
      if (filter.status) params.set('status', filter.status)
      
      const response = await fetch(`/api/content?${params.toString()}`)
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch content')
      }

      setContent(data.content || [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load content')
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this content?')) return

    try {
      const response = await fetch(`/api/content/${id}`, {
        method: 'DELETE',
      })

      if (!response.ok) {
        throw new Error('Failed to delete content')
      }

      setContent(content.filter(item => item.id !== id))
    } catch (err) {
      alert('Failed to delete content')
    }
  }

  const filteredContent = content.filter(item => {
    if (filter.search && !item.title.toLowerCase().includes(filter.search.toLowerCase())) {
      return false
    }
    return true
  })

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    })
  }

  const getTemplateLabel = (template: string) => {
    const labels: Record<string, { label: string; color: string }> = {
      'blog-post': { label: 'Blog', color: 'bg-teal-100 text-teal-700' },
      'social-pack': { label: 'Social Pack', color: 'bg-orange-100 text-orange-700' },
      'social-post': { label: 'Social', color: 'bg-orange-100 text-orange-700' },
      'gmb-post': { label: 'Google', color: 'bg-blue-100 text-blue-700' },
      'email': { label: 'Email', color: 'bg-purple-100 text-purple-700' },
    }
    return labels[template] || { label: template, color: 'bg-gray-100 text-gray-700' }
  }

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto animate-pulse">
        <div className="h-8 w-48 bg-gray-200 rounded mb-6"></div>
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-20 bg-gray-200 rounded-xl"></div>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Spark Library</h1>
        <Link
          href="/dashboard/content"
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-medium transition-colors"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Create a spark
        </Link>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm p-4 rounded-xl mb-6">
          {error}
        </div>
      )}

      {/* Filter Bar */}
      <div className="flex flex-wrap gap-3 mb-6">
        <select 
          className="px-4 py-2.5 border border-gray-200 rounded-lg bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
          value={filter.type}
          onChange={(e) => {
            setFilter({ ...filter, type: e.target.value })
            fetchContent()
          }}
        >
          <option value="">All Types</option>
          <option value="blog-post">Blog Posts</option>
          <option value="social-pack">Social Packs</option>
          <option value="gmb-post">Google Business</option>
          <option value="email">Email</option>
        </select>
        <select 
          className="px-4 py-2.5 border border-gray-200 rounded-lg bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
          value={filter.status}
          onChange={(e) => {
            setFilter({ ...filter, status: e.target.value })
            fetchContent()
          }}
        >
          <option value="">All Status</option>
          <option value="draft">Draft</option>
          <option value="published">Published</option>
          <option value="scheduled">Scheduled</option>
        </select>
        <input
          type="text"
          placeholder="Search content..."
          className="flex-1 min-w-[200px] px-4 py-2.5 border border-gray-200 rounded-lg bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
          value={filter.search}
          onChange={(e) => setFilter({ ...filter, search: e.target.value })}
        />
      </div>

      {/* Content List */}
      {filteredContent.length > 0 ? (
        <div className="bg-white border border-gray-200 rounded-xl divide-y divide-gray-100 shadow-sm">
          {filteredContent.map((item) => {
            const templateInfo = getTemplateLabel(item.template)
            return (
              <div
                key={item.id}
                className="p-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-gray-900 truncate">{item.title || 'Untitled'}</h3>
                  <p className="text-sm text-gray-500">
                    {formatDate(item.created_at)}
                  </p>
                </div>
                <div className="flex items-center gap-3 ml-4">
                  <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${templateInfo.color}`}>
                    {templateInfo.label}
                  </span>
                  <span
                    className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                      item.status === 'published'
                        ? 'bg-green-100 text-green-700'
                        : item.status === 'scheduled'
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {item.status}
                  </span>
                  <button 
                    onClick={() => handleDelete(item.id)}
                    className="text-sm text-gray-400 hover:text-red-600 transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-xl p-12 text-center shadow-sm">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg
              className="w-8 h-8 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No content yet</h3>
          <p className="text-gray-500 mb-6 max-w-sm mx-auto">
            Start creating content to build your library
          </p>
          <Link
            href="/dashboard/content"
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-medium transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Create a spark
          </Link>
        </div>
      )}
    </div>
  )
}